# Second Sight P4CK reverse-engineering notes (v0.1)

## P4CK container
All tested `.pak` files start with `P4CK` and use the same layout.

### Header (16 bytes, little-endian)
| Offset | Type | Meaning |
|---|---|---|
| 0x00 | char[4] | `P4CK` |
| 0x04 | u32 | absolute index offset / end of data region |
| 0x08 | u32 | index size in bytes; always divisible by 16 |
| 0x0C | u32 | names block size |

Invariant in all samples:
`index_offset + index_size + names_size == archive_file_size`

### Data region
Starts at 0x10 and ends at `index_offset`. Payload starts are 16-byte aligned in all tested archives.

### Index record (16 bytes)
| Offset | Type | Meaning |
|---|---|---|
| +0x00 | u32 | filename offset relative to index base |
| +0x04 | u32 | absolute payload offset |
| +0x08 | u32 | payload size |
| +0x0C | u32 | flags (0 in all current samples) |

Filename strings are NUL-terminated ASCII. The names block begins at `index_offset + index_size`.

## Tested sample archives
- `skelg2.pak`: 19 files
- `chair.pak`: 15 files
- `lv52.pak`: 3 files
- `jvs1_cs.pak`: 3 files
- `lv52_raw.pak`: 28 files
- `lv52_tab_raw.pak`: 28 files
- `scripts_raw.pak`: 68 files
- `scripts_tab.pak`: 136 files

Total embedded files recovered: 300.

## Animation observations
Animation-like RAW files have a repeatable little-endian header. Current working interpretation of the first six u32 values:

- u32[0], u32[1]: sentinels / type-dependent values
- u32[2]: animation encoding/flags candidate (commonly 17; camera/uncompressed cases use 0)
- u32[3]: duration/timeline ticks
- u32[4]: frame/sample count including frame 0
- u32[5]: transform channel / bone count

Examples:
- `human_21_bindpose.raw`: duration=1, samples=1, bones=21
- `human_23_bindpose.raw`: duration=1, samples=1, bones=23
- `doc_talk1.raw`: duration=350, samples=89, bones=21
- `asylumjflash1_john_23.raw`: duration=627, samples=158, bones=23
- `asylumjflash1_jayne.raw`: duration=627, samples=158, bones=21
- `asylumjflash1_cam.raw`: duration=627, samples=627, channels=1

After a 60-byte fixed header, animated clips contain a timeline table. Character clips generally store times at approximately 4-tick intervals; the cinematic camera sample uses 1-tick intervals. This strongly links the three `jvs1_cs` tracks to one shared cinematic timeline.

## Script observations
`lv52_raw.pak` contains 28 compiled VM script payloads, and `lv52_tab_raw.pak` contains 28 matching `.tab.raw` files.

The TAB files begin with bytes `32 42 41 54` (`2BAT`, likely a little-endian FourCC corresponding to `TAB2`). The remaining data is a sequence of 32-bit integer pairs ending in `0xFFFFFFFF, 0xFFFFFFFF`. One value in each pair closely tracks offsets within the matching compiled script payload, so this is likely a code-offset/debug/source mapping table. Exact semantics are not yet assigned.

## EXE evidence
The executable contains original internal paths such as:
- `\\build\\win32\\ss\\anim\\cs_anim.c`
- `\\build\\win32\\ss\\anim\\streamanim.c`
- `assets/g2/models/level%d/level%d/win32/output/block%03d.raw`
- `assets/g2/models/level%d/level%d/win32/output/room%d.raw`
- `assets/g2/models/level%d/level%d/win32/output/level%d.raw`

This supports the working plan of extracting level/model RAW assets from the story archives and reconstructing them in a dedicated viewer before Maya/Unreal export.
