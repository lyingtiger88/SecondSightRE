#!/usr/bin/env python3
import argparse, json, os, struct, hashlib
from pathlib import Path

MAGIC = b'P4CK'
HEADER = struct.Struct('<4I')
ENTRY = struct.Struct('<4I')

class P4CKError(Exception):
    pass

class P4CKArchive:
    def __init__(self, path):
        self.path = Path(path)
        self.data = self.path.read_bytes()
        if len(self.data) < HEADER.size:
            raise P4CKError('File too small')
        magic, self.index_offset, self.index_size, self.names_size = HEADER.unpack_from(self.data, 0)
        if self.data[:4] != MAGIC:
            raise P4CKError(f'Bad magic: {self.data[:4]!r}')
        if self.index_offset + self.index_size + self.names_size != len(self.data):
            raise P4CKError('Header section sizes do not add up to file size')
        if self.index_size % ENTRY.size:
            raise P4CKError('Index size is not a multiple of 16 bytes')
        self.count = self.index_size // ENTRY.size
        self.entries = self._read_entries()

    def _cstring(self, offset):
        if not (0 <= offset < len(self.data)):
            raise P4CKError(f'Name offset out of range: {offset}')
        end = self.data.find(b'\0', offset)
        if end < 0:
            raise P4CKError('Unterminated name')
        return self.data[offset:end].decode('ascii')

    def _read_entries(self):
        out = []
        for i in range(self.count):
            p = self.index_offset + i * ENTRY.size
            name_rel, data_offset, data_size, flags = ENTRY.unpack_from(self.data, p)
            name_offset = self.index_offset + name_rel
            name = self._cstring(name_offset)
            end = data_offset + data_size
            if data_offset < HEADER.size or end > self.index_offset:
                raise P4CKError(f'Entry {i} payload out of data region')
            out.append({
                'index': i,
                'name': name,
                'name_rel': name_rel,
                'data_offset': data_offset,
                'size': data_size,
                'flags': flags,
            })
        return out

    def payload(self, entry):
        o, n = entry['data_offset'], entry['size']
        return self.data[o:o+n]

    def manifest(self, hashes=False):
        result = {
            'format': 'P4CK',
            'path': str(self.path),
            'file_size': len(self.data),
            'index_offset': self.index_offset,
            'index_size': self.index_size,
            'names_size': self.names_size,
            'entry_count': self.count,
            'entries': [],
        }
        for e in self.entries:
            row = dict(e)
            if hashes:
                row['sha1'] = hashlib.sha1(self.payload(e)).hexdigest()
            result['entries'].append(row)
        return result

    def extract(self, outdir):
        base = Path(outdir)
        written = []
        for e in self.entries:
            rel = Path(*e['name'].replace('\\','/').split('/'))
            # Avoid absolute paths / parent traversal.
            if rel.is_absolute() or '..' in rel.parts:
                raise P4CKError(f'Unsafe archived path: {e["name"]}')
            dest = base / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(self.payload(e))
            written.append(dest)
        return written

def cmd_list(args):
    a = P4CKArchive(args.archive)
    print(f'{a.path.name}: {a.count} entries')
    print(f'index_offset=0x{a.index_offset:X} index_size={a.index_size} names_size={a.names_size}')
    for e in a.entries:
        print(f'{e["index"]:4d}  off=0x{e["data_offset"]:08X}  size={e["size"]:8d}  flags=0x{e["flags"]:08X}  {e["name"]}')

def cmd_extract(args):
    a = P4CKArchive(args.archive)
    files = a.extract(args.output)
    print(f'Extracted {len(files)} files to {args.output}')

def cmd_manifest(args):
    a = P4CKArchive(args.archive)
    text = json.dumps(a.manifest(hashes=args.hashes), indent=2)
    if args.output:
        Path(args.output).write_text(text, encoding='utf-8')
        print(args.output)
    else:
        print(text)

def main():
    ap = argparse.ArgumentParser(description='Second Sight P4CK archive inspector/extractor')
    sp = ap.add_subparsers(dest='cmd', required=True)
    p = sp.add_parser('list'); p.add_argument('archive'); p.set_defaults(func=cmd_list)
    p = sp.add_parser('extract'); p.add_argument('archive'); p.add_argument('-o','--output',required=True); p.set_defaults(func=cmd_extract)
    p = sp.add_parser('manifest'); p.add_argument('archive'); p.add_argument('-o','--output'); p.add_argument('--hashes',action='store_true'); p.set_defaults(func=cmd_manifest)
    args = ap.parse_args(); args.func(args)

if __name__ == '__main__':
    main()
